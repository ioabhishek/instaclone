const mongoose = require('mongoose');

const postSchema = new mongoose.Schema({
  image: {
    type: String,
  },
  author: {
    type: String,
  },
  location: {
    type: String,
  },
  description: {
    type: String,
  },
  cloudinary_id: {
    type: String
  },
});

module.exports = mongoose.model('user', postSchema);