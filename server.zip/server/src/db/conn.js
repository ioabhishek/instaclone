const mongoose = require('mongoose');
const CONNECTION_URL = 'mongodb+srv://instaclone:insta123@cluster0.b3kls.mongodb.net/?retryWrites=true&w=majority'

// mongoose.connect('mongodb://localhost:27017/instaclone')
mongoose.connect(CONNECTION_URL)
.then(() => {
  console.log('Connection is successfull');
}).catch((e) => {
  console.log('No Connection');
}); 